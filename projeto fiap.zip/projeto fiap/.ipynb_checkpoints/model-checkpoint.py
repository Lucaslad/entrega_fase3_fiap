import pandas as pd
import numpy as np
import joblib
import warnings
warnings.filterwarnings('ignore')

def model_fn():
    model = joblib.load("randomforestclassifier.joblib")
    return model

def input_fn():
    df = pd.read_csv("input/test.csv")
    return df

def custom_dataprep():
    df = input_fn()

    df["HomePlanet"].fillna("Earth", inplace=True)
    df["CryoSleep"].fillna(False, inplace=True)
    df["Cabin"].fillna("D/176/S", inplace=True)
    df["Age"].fillna(27, inplace=True)
    df["RoomService"].fillna(0, inplace=True)
    df["FoodCourt"].fillna(0, inplace=True)
    df["ShoppingMall"].fillna(0, inplace=True)
    df["Spa"].fillna(0, inplace=True)
    df["VRDeck"].fillna(0, inplace=True)
    
    df["Age_group"] = pd.cut(df["Age"], bins=[-1, 10, 17, 25, np.inf], labels=[1, 2, 3, 4])
    df["total_spent"] = df["RoomService"] + df["FoodCourt"] + df["ShoppingMall"] + df["Spa"] + df["VRDeck"]
    df["log_total_spent"] = np.log(1+df["total_spent"].astype("int"))
    df["spent"] = np.where(df["total_spent"]==0, 0, 1)
    df['Group'] = df['PassengerId'].apply(lambda x: x.split('_')[0]).astype(int)
    df['Group_size']=df['Group'].map(lambda x: pd.concat([df['Group'], df['Group']]).value_counts()[x])
    df["solo"] = np.where(df["Group_size"]==1, 1, 0)
    df["deck"] = df["Cabin"].str.split("/", expand=True)[0]
    df["side"] = df["Cabin"].str.split("/", expand=True)[2]

    df.drop(columns=["PassengerId", "Cabin", "Name", "Group", "VIP"], inplace=True)

    cols = ['RoomService','FoodCourt','ShoppingMall','Spa','VRDeck']

    for value in cols:
        df[value] = np.log(1+df[value])

    df["CryoSleep"] = df["CryoSleep"].astype("int")
    df["Age_group"] = df["Age_group"].astype("int")

    deck_dict = {
    "A":1,
    "B":2,
    "C":3,
    "D":4,
    "E":5,
    "F":6,
    "G":7,
    "T":6
    }

    df["deck"] = df["deck"].map(deck_dict)

    df = pd.get_dummies(df, columns=['HomePlanet', 'Destination', 'side'])

    boolean_columns = df.select_dtypes(include='bool')
    df[boolean_columns.columns] = boolean_columns.astype(int)

    return df

def predict_fn():
    input_data = custom_dataprep()
    model = model_fn()
    prediction = model.predict(input_data)
    
    return prediction

def output_fn():
    df = input_fn()
    prediction = predict_fn()
    df['Transported'] = prediction
    
    df.to_csv("output/previsao.csv", index=False)

output_fn()

